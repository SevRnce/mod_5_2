/**
 * 
 */
/**
 * 
 */
import java.util.Scanner;

public class Recursion{
	public static int product(int[] Numbers, int count) {
		//setup for calculation
		int product = 1;
		count = count - 1;
		//initiate number get
		if (count < 0){
			product = 1;
		}
		//find product



else {
			product = product(Numbers, count) * Numbers[count];
		}
		return product;
	}
	public static void main(String[] args){
		//input setup
		int[] input = new int[5];
		Scanner scan = new Scanner(System.in);
		//input prompt
		System.out.println("Enter 5 numbers, hit 'enter' after each one.");
		for(int i = 0; i<5; i++){
			input[i] = scan.nextInt();
		}
		//show user input received
		System.out.print("Numbers you input: ");
		
		for(int i = 0; i < 5; i++) {
			System.out.print(input[i] + " ");
		}
		
		System.out.println("");
		System.out.println("Product of input numbers: " + product(input, input.length));
		
		scan.close();	
	}
}